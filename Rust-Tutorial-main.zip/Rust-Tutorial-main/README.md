# Rust-Tutorial
Rust is the language of choice for those looking for high performance, memory safety and all the tools needed to write error free code with ease. In this tutorial I created a full course on programming with Rust.
